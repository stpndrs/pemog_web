<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Latihan While PHP</title>
</head>
<body>
    <h2>Contoh penggunaan WHILE:</h2>
    <?php 
    // $i = 0;
    // while ($i < 10) {
    //     echo "$i. Saya berjanji tidak akan nakal lagi <br>";
    //     $i++;
    // }

    $z = 10;
    while ($z > 0) {
        echo "$z. Saya berjanji tidak akan nakal lagi <br>";
        $z--;
    }
    ?>
</body>
</html>