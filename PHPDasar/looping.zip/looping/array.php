<?php 
$names = ['Fatur', 'Ihsan']; // deklarasi array
echo $names[1]; // mencetak nilai array
print_r($names); // mengecek seluruh isi array
var_dump($names); // mengecek seluruh isi variabel
$names[2] = 'Vicky'; // menambahkan data ke dalam index array
echo $names[2]; // mencetak nilai array
echo "<br>";
$data = ['nis' => 123, 'nama' => 'Abdul']; // array asosiatif
echo $data['nis'];
echo $data['nama'];

// $names = array(); alternatif deklarasi array



?>