<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Latihan For PHP</title>
</head>

<body>
    <h2>Contoh penggunaan FOR:</h2>
    <?php
    // for ($i = 1; $i <= 100; $i++) {
    //     echo "$i. saya berjanji tidak akan nakal lagi <br>";
    // }
    for ($i = 100; $i >= 1; $i--) {
        echo "$i. saya berjanji akan disiplin mengumpulkan tugas <br>";
    }
    ?>
</body>

</html>